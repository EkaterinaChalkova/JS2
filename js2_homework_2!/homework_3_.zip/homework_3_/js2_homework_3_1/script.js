function makeGETRequest(url, success, error) {
    var xhr;

    if (window.XMLHttpRequest) {
        xhr = new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        xhr = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status >= 400 || xhr.status == 0) {
                error(xhr.status);
            } else {
                success(xhr.responseText);
            }
        }
    }

    xhr.open('GET', url, true);
    xhr.send();
}


const API_URL = 'https://raw.githubusercontent.com/GeekBrainsTutorial/online-store-api/master/responses'

const promise = new Promise((success, error) => {
    makeGETRequest($API_URL / catalogData.json, success, error)
})
    .then(
        (x) => {
            console.log('im success');
            console.log(JSON.parse(x))
        }
    )
    .catch(
        (x) => {
            console.log('im error');
            console.log(x)
        }
    );